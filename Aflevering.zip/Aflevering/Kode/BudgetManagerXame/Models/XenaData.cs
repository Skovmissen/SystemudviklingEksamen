﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BudgetManagerXame.Models
{
    public class XenaData //af Patrick
    {
        public string Finanskonti { get; set; }
        public string id_code { get; set; }
        public string access_token { get; set; }
        public string token { get; set; }
        public string Fis_ID { get; set; }

    }
}