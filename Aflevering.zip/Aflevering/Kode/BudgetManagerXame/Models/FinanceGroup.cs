﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BudgetManagerXame.Models
{
    public class FinanceGroup //af Patrick
    {
        public string Name { get; set; }
        public double Result { get; set; }
    }
}