USE [BudgetManagerExam]
GO

INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Jan')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Feb')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Mar')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Apr')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Maj')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Jun')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Jul')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Aug')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Sep')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Okt')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Nov')
INSERT INTO [dbo].[Period] ([Name]) VALUES (N'Dec')


